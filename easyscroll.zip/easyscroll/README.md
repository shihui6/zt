this is a tiny scroll bar plugin for the vue2.0.
for more information please visit https://github.com/GarveyZuo/EasyScroll.git