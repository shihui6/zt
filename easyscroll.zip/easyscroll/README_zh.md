这是一个轻量级vue2.0滚动条插件，实现了自定义滚动条轨道颜色，滚动条颜色，宽度，偏移量等属性。
具体信息请访问：https://github.com/GarveyZuo/EasyScroll.git；